<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */

$routes->get('/', 'Home::index', ['filter' => 'auth']);

$routes->get('login', 'AuthController::login');
$routes->post('login', 'AuthController::login');
$routes->get('logout', 'AuthController::logout');

$routes->group('produk', ['filter' => 'auth'], function ($routes) { 
    $routes->get('', 'ProdukController::index');
    $routes->post('', 'ProdukController::create');
    $routes->post('edit/(:any)', 'ProdukController::edit/$1');
    $routes->get('delete/(:any)', 'ProdukController::delete/$1');
});

$routes->get('keranjang', 'TransaksiController::index', ['filter' => 'auth']);

$routes->get('contact', 'ContactController::index', ['filter' => 'auth']);

$routes->group('kategori_produk', ['filter' => 'auth'], function ($routes) {
    $routes->get('/', 'KategoriProdukController::index');
    $routes->get('tambah', 'KategoriProdukController::create');
    $routes->post('simpan', 'KategoriProdukController::store');
    $routes->get('edit/(:num)', 'KategoriProdukController::edit/$1');
    $routes->post('update/(:num)', 'KategoriProdukController::update/$1');
    $routes->get('hapus/(:num)', 'KategoriProdukController::delete/$1');
});







